#!/bin/bash

time=$(date +%s)
echo  "$time"
let time=time*2
echo "$time"

for ((i=1; i<=20; i++))
do
 echo "$i"
done
